class Carro:
     def __init__(self,modelo,ano,cor,potencia,placa):
        self.modelo = modelo
        self.ano = ano
        self.cor = cor
        self.potencia = potencia
        self.placa = placa